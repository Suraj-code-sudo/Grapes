import numpy as np
random_ = np.random.randint(low = 3,high=8,size=10)
print('Maximum: ', max(random_))
print('Minimum: ', min(random_))